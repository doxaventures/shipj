<?php

	define('SHOPIFY_SHOP', 'your-store.myshopify.com');
	define('SHOPIFY_APP_API_KEY', 'your-store.myshopifyapi-key');
	define('SHOPIFY_APP_PASSWORD', 'your store shopify api password');

?>
